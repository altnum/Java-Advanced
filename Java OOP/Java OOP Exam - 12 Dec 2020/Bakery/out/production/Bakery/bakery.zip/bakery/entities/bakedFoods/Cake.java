package bakery.entities.bakedFoods;

public class Cake extends BaseFood {
    private final static int INITIAL_BREAD_PORTION = 245;
    //constructor?
    public Cake(String name, double price) {
        super(name, INITIAL_BREAD_PORTION, price);
    }
}
