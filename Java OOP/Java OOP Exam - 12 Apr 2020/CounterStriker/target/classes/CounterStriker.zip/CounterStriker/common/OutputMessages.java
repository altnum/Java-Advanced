package CounterStriker.common;

public class OutputMessages {
    public static final String SUCCESSFULLY_ADDED_PLAYER = "Successfully added player %s.";

    public static final String SUCCESSFULLY_ADDED_GUN = "Successfully added gun %s.";

    public static final String TERRORIST_WINS = "Terrorist wins!";

    public static final String COUNTER_TERRORIST_WINS = "Counter Terrorist wins!";
}
