package animals;

public enum Gender {
    MALE,
    FEMALE
}
