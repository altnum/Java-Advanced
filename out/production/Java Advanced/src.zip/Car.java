public class Car {
    private String brand;
    private String Model;
    private int horsepower;

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return Model;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        Model = model;
    }

    public int getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }
}
